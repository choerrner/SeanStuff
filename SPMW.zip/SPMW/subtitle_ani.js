
const text2 = document.querySelector(".sub_fancy")

const strText2 = text2.textContent;

const splitText2 = strText2.split("");

text2.textContent = "";

for(let j = 0; j < splitText2.length; j++) {
  text2.innerHTML += "<span>" + splitText2[j] + "</span>"
}


let char2 = 0;
let timer2 = setInterval(onTick2, 50);

console.log(text2)



function onTick2(){
  const span2 = text2.querySelectorAll('span')[char2]
  span2.classList.add('fade2');
  char2++
  if(char2 === splitText2.length){
    complete2();
    return;
  }
}


function complete2(){
  clearInterval(timer2);
  timer2 = null;
}
